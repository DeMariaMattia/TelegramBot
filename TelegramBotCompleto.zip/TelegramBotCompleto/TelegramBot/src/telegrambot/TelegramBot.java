package telegrambot;

import TelegramAPI.TelegramAPIClass;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class TelegramBot {

    public static void main(String[] args) throws IOException, MalformedURLException, URISyntaxException, SAXException, ParserConfigurationException {
        //PRENDERE VALORE DEI MESSAGGI RICHIAMANDO METODO DELLA LIBRERIA CREATA
        TelegramAPIClass API = new TelegramAPIClass();
        //API.SetChat_Utente();
        GetUpdate ThUpdate = new GetUpdate();
        ThUpdate.start();
        try {
            ThUpdate.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(TelegramBot.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

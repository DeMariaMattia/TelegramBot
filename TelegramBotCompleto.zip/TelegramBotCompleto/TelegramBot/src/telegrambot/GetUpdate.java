package telegrambot;

import TelegramAPI.TelegramAPIClass;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class GetUpdate extends Thread {

    TelegramAPIClass Api = new TelegramAPIClass();
    int TempoAttesa = 30000, Ripetizioni = 3000;

    public GetUpdate() {
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i < Ripetizioni; i++) {
                Api.SetChat_Utente();
                Api.LeggiPubblicità();
                Thread.sleep(TempoAttesa);
            }
        } catch (IOException ex) {
            Logger.getLogger(GetUpdate.class.getName()).log(Level.SEVERE, null, ex);
        } catch (URISyntaxException ex) {
            Logger.getLogger(GetUpdate.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(GetUpdate.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(GetUpdate.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(GetUpdate.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

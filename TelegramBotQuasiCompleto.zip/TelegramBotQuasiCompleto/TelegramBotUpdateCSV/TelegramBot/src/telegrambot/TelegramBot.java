package telegrambot;

import TelegramAPI.TelegramAPIClass;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class TelegramBot {

    public static void main(String[] args) throws IOException, MalformedURLException, URISyntaxException, SAXException, ParserConfigurationException {
        //PRENDERE VALORE DEI MESSAGGI RICHIAMANDO METODO DELLA LIBRERIA CREATA
        TelegramAPIClass API = new TelegramAPIClass();
        API.SetChat_Utente();
    }

}

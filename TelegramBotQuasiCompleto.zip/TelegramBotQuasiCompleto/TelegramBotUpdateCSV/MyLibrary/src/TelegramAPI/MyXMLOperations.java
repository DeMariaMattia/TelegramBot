package TelegramAPI;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

public class MyXMLOperations {

    private Document document;

    public Document getDocument() {
        return document;
    }

    public List parseDocument(String filename)
            throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory factory;
        DocumentBuilder builder;
        Element root, element;
        NodeList nodelist;
        // creazione dell’albero DOM dal documento XML
        factory = DocumentBuilderFactory.newInstance();
        builder = factory.newDocumentBuilder();
        document = builder.parse(filename);
        root = document.getDocumentElement();
        List<Lat_Lon> dati = new ArrayList();
        nodelist = root.getElementsByTagName("place");
        if (nodelist != null && nodelist.getLength() > 0) {
            int numNode = nodelist.getLength();
            for (int i = 0; i < numNode; i++) {
                element = (Element) nodelist.item(i);
                String lat = element.getAttribute("lat");
                String lon = element.getAttribute("lon");
                double LAT = Double.parseDouble(lat);
                double LON = Double.parseDouble(lon);
                Lat_Lon Coordinate = new Lat_Lon(LAT, LON);
                dati.add(Coordinate);
            }
        }
        return dati;
    }
}

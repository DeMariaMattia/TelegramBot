package TelegramAPI;
public class Lat_Lon {
    private double Lat,Lon;

    public Lat_Lon() {
    }

    public Lat_Lon(double Lat, double Lon) {
        this.Lat = Lat;
        this.Lon = Lon;
    }

    public double getLat() {
        return Lat;
    }

    public void setLat(double Lat) {
        this.Lat = Lat;
    }

    public double getLon() {
        return Lon;
    }

    public void setLon(double Lon) {
        this.Lon = Lon;
    }

    @Override
    public String toString() {
        return "Lat=" + Lat + ", Lon=" + Lon;
    }
    
}

package TelegramAPI;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.ParserConfigurationException;
import org.json.*;
import org.xml.sax.SAXException;

public class TelegramAPIClass {

    String TOKEN = "5275008360:AAEvvZyBCXHkFNbjVA_QYKy2HIQZirrCvI0";
    long CHAT_ID = 0;
    String Utente;
    StringBuilder sb = new StringBuilder();

    public void SetChat_Utente() throws MalformedURLException, IOException, URISyntaxException, SAXException, ParserConfigurationException {
        String temp = "";
        URL url = new URL("https://api.telegram.org/bot" + TOKEN + "/getUpdates");
        Scanner s = new Scanner(url.openStream());
        s.useDelimiter("\u001a");
        String jsonString = s.next();
        JSONObject Oggetto = new JSONObject(jsonString);
        JSONArray Vettore = Oggetto.getJSONArray("result");
        long ID_Messaggio = Vettore.getJSONObject(Vettore.length() - 1).getJSONObject("message").getInt("message_id");
        long Chat_ID = Vettore.getJSONObject(Vettore.length() - 1).getJSONObject("message").getJSONObject("from").getInt("id");
        String Messaggio = Vettore.getJSONObject(Vettore.length() - 1).getJSONObject("message").getString("text");
        String Comando = Messaggio.substring(0, 8);
        String NumeroComando = Messaggio.substring(8, 9);
        String Mex="";
        if (Comando.compareTo("/command") == 0) {
            if (NumeroComando.compareTo("1") == 0) {
                Mex = Messaggio.replaceAll("/command1", "");
                Mex = Mex.trim();
            } else {
                Mex = Messaggio.replaceAll("/command2", "");
                Mex = Mex.trim();
            }
            System.out.println("IdMessaggio= " + ID_Messaggio);
            System.out.println("ChatId= " + Chat_ID);
            System.out.println(Mex);
            Utente = Vettore.getJSONObject(Vettore.length() - 1).getJSONObject("message").getJSONObject("chat").getString("first_name");
            CHAT_ID = Chat_ID;
            LeggiMessaggio(Mex);
        } else {
            System.out.println("Comando non valido...");
        }

    }

    public void RispondiMessaggio(String tmp) throws MalformedURLException, IOException {
        String Risposta = tmp;
        String urlString = "https://api.telegram.org/bot" + TOKEN + "/sendMessage?chat_id=" + CHAT_ID + "&text=" + Risposta;
        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();
        StringBuilder sb = new StringBuilder();
        InputStream is = new BufferedInputStream(conn.getInputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String inputLine = "";
        while ((inputLine = br.readLine()) != null) {
            sb.append(inputLine);
        }
    }

    public void LeggiMessaggio(String Mess) throws MalformedURLException, IOException, URISyntaxException, SAXException, ParserConfigurationException {

        BufferedReader in = null;
        PrintWriter out;
        String LatitudineLongitudine = "";
        out = new PrintWriter("xml/Coordinate.xml");
        URL url = new URL("https://nominatim.openstreetmap.org/search?q=" + Mess + "&format=xml&addressdetails=1");
        in = new BufferedReader(new InputStreamReader(url.openStream()));
        String line;
        while ((line = in.readLine()) != null) {
            out.println(line);
        }
        in.close();
        out.close();
        MyXMLOperations xml = new MyXMLOperations();
        String xmlFile = "xml/Coordinate.xml";
        try {
            List<Lat_Lon> dati = new ArrayList<>();
            dati = xml.parseDocument(xmlFile);
            for (int i = 0; i < dati.size(); i++) {
                Lat_Lon info = dati.get(i);
                LatitudineLongitudine = ("LAT = " + info.getLat() + " LON = " + info.getLon());
                System.out.println(LatitudineLongitudine);
                RispondiMessaggio(LatitudineLongitudine);
                SalvaInfoUtente(info.getLat(), info.getLon());
            }
        } catch (ParserConfigurationException | SAXException | IOException exception) {
            System.out.println(exception);
        }
    }

    private void SalvaInfoUtente(Double Lat, Double Lon) throws FileNotFoundException, IOException {

        String File = "DatiUtenti.csv";
        FileWriter Writer = new FileWriter(File, true);
        Writer.append(Long.toString(CHAT_ID));
        Writer.append(';');
        Writer.append(Utente);
        Writer.append(';');
        Writer.append(Lat.toString());
        Writer.append(';');
        Writer.append(Lon.toString());
        Writer.append(';');
        Writer.append('\n');
        Writer.close();
        System.out.println("CSV aggiornato correttamente.");

    }

}

package TelegramAPI;

import static java.awt.SystemColor.text;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;
import org.json.*;

public class TelegramAPIClass {

    String TOKEN = "5121985240:AAFozdRnzzdYJLp7pW5IXt3JMP6XGBpNXf8";
    String CHAT_ID = "389929585";

    public void LeggiMessaggio() throws MalformedURLException, IOException {
        //TEST
        String temp = "";
        URL url = new URL("https://api.telegram.org/bot" + TOKEN + "/getUpdates");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();
        if (conn.getResponseCode() == 200) {
            Scanner scan = new Scanner(url.openStream());
            while (scan.hasNext()) {
                temp = scan.nextLine();
                System.out.println(temp);
            }
        }
        String jsonString = temp;
        System.out.println(temp);
        //JSONObject obj = new JSONObject(jsonString);
        //String Messaggio = obj.getJSONObject("message").getString("message_id");
        //JSONArray arr = obj.getJSONArray("message"); // notice that `"posts": [...]`
        /*for (int i = 0; i < arr.length(); i++) {
            String message_id = arr.getJSONObject(i).getString("message_id");
        }*/
    }

    public void RispondiMessaggio() throws MalformedURLException, IOException {
        String Risposta = "Ciao anche a te!!";
        String urlString = "https://api.telegram.org/bot" + TOKEN + "/sendMessage?chat_id=" + CHAT_ID + "&text=" + Risposta;
        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();
        StringBuilder sb = new StringBuilder();
        InputStream is = new BufferedInputStream(conn.getInputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String inputLine = "";
        while ((inputLine = br.readLine()) != null) {
            sb.append(inputLine);
        }
    }
}

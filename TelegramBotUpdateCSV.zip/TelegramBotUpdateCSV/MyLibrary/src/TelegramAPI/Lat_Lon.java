package TelegramAPI;
public class Lat_Lon {
    private float Lat,Lon;

    public Lat_Lon() {
    }

    public Lat_Lon(float Lat, float Lon) {
        this.Lat = Lat;
        this.Lon = Lon;
    }

    public float getLat() {
        return Lat;
    }

    public void setLat(float Lat) {
        this.Lat = Lat;
    }

    public float getLon() {
        return Lon;
    }

    public void setLon(float Lon) {
        this.Lon = Lon;
    }

    @Override
    public String toString() {
        return "Lat=" + Lat + ", Lon=" + Lon;
    }
    
}

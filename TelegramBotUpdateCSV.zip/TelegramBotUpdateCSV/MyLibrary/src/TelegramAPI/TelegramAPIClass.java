package TelegramAPI;

import static java.awt.SystemColor.text;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import static java.lang.System.out;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.json.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class TelegramAPIClass {

    String TOKEN = "5275008360:AAEvvZyBCXHkFNbjVA_QYKy2HIQZirrCvI0";
    int CHAT_ID = 0;
    String Utente;
    public void SetChat_Utente() throws MalformedURLException, IOException, URISyntaxException, SAXException, ParserConfigurationException {
        String temp = "";
        URL url = new URL("https://api.telegram.org/bot" + TOKEN + "/getUpdates");
        Scanner s = new Scanner(url.openStream());
        s.useDelimiter("\u001a");
        String jsonString = s.next();
        JSONObject Oggetto = new JSONObject(jsonString);
        JSONArray Vettore = Oggetto.getJSONArray("result");
        for (int i = 0; i < Vettore.length(); i++) {
            int ID_Messaggio = Vettore.getJSONObject(i).getJSONObject("message").getInt("message_id");
            int Chat_ID = Vettore.getJSONObject(i).getJSONObject("message").getJSONObject("from").getInt("id");
            String Messaggio = Vettore.getJSONObject(i).getJSONObject("message").getString("text");
            if (Messaggio.length() > 8) {
                String Mex = Messaggio.replaceAll("/command1", "");
                Mex.trim();
                  System.out.println(Mex);
                   LeggiMessaggio(Mex);
            }
          
           
            Utente = Vettore.getJSONObject(i).getJSONObject("message").getJSONObject("chat").getString("first_name");
            CHAT_ID = Chat_ID;
            //System.out.println("CHAT_ID:\n" + Chat_ID + "\n" + "Messaggio\n" + Messaggio + "\n" + "Utente\n" + Utente + "\n");
        }
    }

    public void RispondiMessaggio(String tmp) throws MalformedURLException, IOException {
        String Risposta = tmp;
        String urlString = "https://api.telegram.org/bot" + TOKEN + "/sendMessage?chat_id=" + CHAT_ID + "&text=" + Risposta;
        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();
        StringBuilder sb = new StringBuilder();
        InputStream is = new BufferedInputStream(conn.getInputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String inputLine = "";
        while ((inputLine = br.readLine()) != null) {
            sb.append(inputLine);
        }
    }

    public void LeggiMessaggio(String Mess) throws MalformedURLException, IOException, URISyntaxException, SAXException, ParserConfigurationException {

        BufferedReader in = null;
        PrintWriter out;
        String LatitudineLongitudine="";
        out = new PrintWriter("xml/Coordinate.xml");
        URL url = new URL("https://nominatim.openstreetmap.org/search?q=" + Mess + "&format=xml&polygon_geojson=1&addressdetails=1");
        in = new BufferedReader(new InputStreamReader(url.openStream()));
        String line;
        while ((line = in.readLine()) != null) {
            //System.out.println(line);
            out.println(line);
        }
        in.close();
        out.close();
        MyXMLOperations xml = new MyXMLOperations();
        String xmlFile = "xml/Coordinate.xml";
        try {
            List<Lat_Lon> dati = new ArrayList<>();
            dati = xml.parseDocument(xmlFile);
            System.out.println("---------------------------------------------------");
            for (int i = 0; i < dati.size(); i++) {
                Lat_Lon info = dati.get(i);
                LatitudineLongitudine=("LAT = " + info.getLat() + " LON = " + info.getLon());
                RispondiMessaggio(LatitudineLongitudine);
                SalvaInfoUtente(info.getLat(),info.getLon());
            }
            System.out.println("---------------------------------------------------");
        } catch (ParserConfigurationException | SAXException | IOException exception) {
            System.out.println(exception);
        }
    }
    private void SalvaInfoUtente(Float Lat, Float Lon) throws FileNotFoundException{
        File FileCSV= new File("DatiUtenti.csv");
        PrintWriter out = new PrintWriter(FileCSV);
        out.print(Utente);
        out.print(CHAT_ID);
        out.print(Lat);
        out.print(Lon);
    }
}

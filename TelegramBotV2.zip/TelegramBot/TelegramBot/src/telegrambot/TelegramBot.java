package telegrambot;

import TelegramAPI.TelegramAPIClass;
import java.io.IOException;
import org.json.*;

public class TelegramBot {

    public static void main(String[] args) throws IOException {
        //PRENDERE VALORE DEI MESSAGGI RICHIAMANDO METODO DELLA LIBRERIA CREATA
        TelegramAPIClass API = new TelegramAPIClass();
        API.SetChat_Utente();
        API.RispondiMessaggio();
    }

}

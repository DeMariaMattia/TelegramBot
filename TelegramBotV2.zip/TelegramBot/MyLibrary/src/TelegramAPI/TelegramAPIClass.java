package TelegramAPI;

import static java.awt.SystemColor.text;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;
import org.json.*;

public class TelegramAPIClass {

    String TOKEN = "5121985240:AAFozdRnzzdYJLp7pW5IXt3JMP6XGBpNXf8";
    int CHAT_ID = 0;

    public void SetChat_Utente() throws MalformedURLException, IOException {
        String temp = "";
        URL url = new URL("https://api.telegram.org/bot" + TOKEN + "/getUpdates");
        Scanner s = new Scanner(url.openStream());
        s.useDelimiter("\u001a");
        String jsonString = s.next();
        JSONObject Oggetto = new JSONObject(jsonString);
        JSONArray Vettore = Oggetto.getJSONArray("result");
        for (int i = 0; i < Vettore.length(); i++) {
            int ID_Messaggio = Vettore.getJSONObject(i).getJSONObject("message").getInt("message_id");
            int Chat_ID = Vettore.getJSONObject(i).getJSONObject("message").getJSONObject("from").getInt("id");
            String Messaggio = Vettore.getJSONObject(i).getJSONObject("message").getString("text");
            String Utente =Vettore.getJSONObject(i).getJSONObject("message").getJSONObject("chat").getString("first_name");
            CHAT_ID=Chat_ID;
            System.out.println("CHAT_ID:\n"+Chat_ID+"\n"+"Messaggio\n"+Messaggio+"\n"+"Utente\n"+Utente+"\n");
        }
    }

    public void RispondiMessaggio() throws MalformedURLException, IOException {
        String Risposta = "Ciao anche a te!!";
        String urlString = "https://api.telegram.org/bot" + TOKEN + "/sendMessage?chat_id=" + CHAT_ID + "&text=" + Risposta;
        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();
        StringBuilder sb = new StringBuilder();
        InputStream is = new BufferedInputStream(conn.getInputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String inputLine = "";
        while ((inputLine = br.readLine()) != null) {
            sb.append(inputLine);
        }
    }
}
